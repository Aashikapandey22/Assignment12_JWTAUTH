const jwt = require("jsonwebtoken");

// Verifies the JWT sent as:  Authorization: Bearer <token>
module.exports = (req, res, next) => {
  const authHeader = req.headers.authorization;

  // 1. Read token from Authorization header + 2. Bearer format check
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized: No token provided" });
  }

  const token = authHeader.split(" ")[1];

  try {
    // 3. Verify token using JWT secret
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    // 4. Valid -> continue
    next();
  } catch (err) {
    // 5. Invalid / expired -> reject
    return res.status(401).json({ message: "Unauthorized: Invalid or expired token" });
  }
};
